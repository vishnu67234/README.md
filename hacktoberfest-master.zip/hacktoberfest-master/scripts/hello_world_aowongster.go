// LANGUAGE: go1.8.3
// AUTHOR: Alistair Wong
// GitHub: https://github.com/aowongster
package main

import "fmt"

func main() {
	fmt.Println("Hello world!")
}
