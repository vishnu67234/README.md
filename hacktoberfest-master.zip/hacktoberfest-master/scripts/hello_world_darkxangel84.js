// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Aimee Tacchi
// GITHUB: https://github.com/darkxangel84

function helloWorld(message){
	if(message === "Hello World"){
		console.log(message);
	} else {
		console.log("This entered the wrong message!");
	}
}

helloWorld("Hello World");