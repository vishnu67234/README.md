# LANGUAGE: Python 2.7.x
# ENV: [GCC 4.8.2] on linux
# AUTHOR: Sukeerthi Khadri
# GITHUB: https://github.com/Sukeer/hacktoberfest

print "Hello World, my name is Sukeer!"
