-- LANGUAGE: Lua
-- AUTHOR: Dustin Woods
-- GITHUB: https://github.com/dustinywoods

print ("Hello, World!")