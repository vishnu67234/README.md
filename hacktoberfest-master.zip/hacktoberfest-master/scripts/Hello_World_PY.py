# LANGUAGE: Python
# AUTHOR: Nikhil
# GITHUB: https://github.com/computelarge
print("Hello World!")
