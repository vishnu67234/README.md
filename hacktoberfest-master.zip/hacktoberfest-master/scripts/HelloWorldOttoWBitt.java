// LANGUAGE: Java
// ENV: HelloWorldOttoWBitt.java
// AUTHOR: Otto Bittencourt
// GITHUB: https://github.com/OttoWBitt
class HelloWorldOttoWBitt{
	public static void main(String[] args) {
		System.out.println("Hello Wolrd!!! - HacktoberFest 2017");
	}
}