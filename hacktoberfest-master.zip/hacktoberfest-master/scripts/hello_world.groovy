/*
  LANGUAGE: GROOVY
  AUTHOR: coastalchief
  GITHUB: https://github.com/coastalchief
*/

println 'Hello World!'