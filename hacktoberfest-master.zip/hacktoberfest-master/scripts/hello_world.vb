// LANGUAGE: Visual Basic
// ENV: .Net
// AUTHOR: Omer
// GITHUB: https://github.com/omerl13

Imports System

Module Program
    Sub Main(args As String())
        Console.WriteLine("Hello World!")
    End Sub
End Module
