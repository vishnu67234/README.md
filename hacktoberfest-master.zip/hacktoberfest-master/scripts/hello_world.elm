-- LANGUAGE: elm
-- AUTHOR: kaptajnen
-- GITHUB: https://github.com/kaptajnen

import Html

main = Html.h1 [] [Html.text "Hello, world!"]