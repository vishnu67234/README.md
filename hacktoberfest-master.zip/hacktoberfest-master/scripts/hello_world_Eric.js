// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Eric Bryant
// GITHUB: https://github.com/shmickle

let script = 'Hello World!';

console.log(script);
