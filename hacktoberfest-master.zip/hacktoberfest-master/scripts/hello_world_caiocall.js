// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Caio Calderari
// GITHUB: https://github.com/caiocall

console.log('Hello, World!');
