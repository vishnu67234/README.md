/*
  LANGUAGE: JAVA
  AUTHOR: Chathumina Vimukthi
  GITHUB: https://github.com/ChathuminaVimukthi
*/

public class Chathumina {

    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }

}
