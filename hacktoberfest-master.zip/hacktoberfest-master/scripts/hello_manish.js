// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Manish Mittal
// GITHUB: https://github.com/manishmittal9

console.log(“Hello World! I’m Manish Mittal, a budding entrepreneur and tech-enthusiast.”);