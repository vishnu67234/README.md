# Language: Ruby
# Author: Gabe Dunn
# GitHub: https://github.com/redxtech

puts 'Hello, World!'