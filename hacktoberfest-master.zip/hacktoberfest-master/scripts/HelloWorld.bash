#!/bin/bash
# By David Cabezas 
# github.com/dcabezas98


printf "Hello World!\n"
