//Language: Javascript
//Env: Node.js
//Author: Jonathan Rinciari
//Github: https://github.com/jonathanrinciari

var userName = "Jon Rinciari"
function hello_world(name){
    console.log(name + " says Hello World!")
}

hello_world(userName)
