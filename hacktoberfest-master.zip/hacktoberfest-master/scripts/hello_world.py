// LANGUAGE: python
// ENV: hello.py
// AUTHOR: Sanny Candidier
// GITHUB: https://github.com/sannycand

print("Hello, World!")
