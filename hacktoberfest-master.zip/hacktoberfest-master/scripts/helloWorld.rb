# Language: Ruby
# Author: Amit Chambial
# GitHub: https://github.com/devaman
print "Hello World"