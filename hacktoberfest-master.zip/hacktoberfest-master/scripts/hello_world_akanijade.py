# LANGUAGE: python
# AUTHOR: Akani
# GITHUB: https://github.com/akanijade

print "Hello World."
