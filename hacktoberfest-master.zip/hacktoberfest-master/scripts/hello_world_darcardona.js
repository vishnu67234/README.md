// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Darwin Cardona
// GITHUB: https://github.com/darcardona

console.log('Hello, World!');
