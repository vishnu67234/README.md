# LANGUAGE: R
# ENV: R Studio
# AUTHOR: Aniket
# GITHUB: https://github.com/AniketRoy

print("Hello, world!")
