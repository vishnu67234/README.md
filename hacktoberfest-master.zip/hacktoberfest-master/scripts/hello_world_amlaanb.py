import sys

print("Hello, World!")