// LANGUAGE: Java
// AUTHOR: Jason Lin
// GITHUB: https://github.com/JasonLin43212

public class Jason {
	public static void main(String[]args){
		System.out.println("Hello, World!");
	}
}
