// Language: JavaScript
// Author: Christian Hernandez

var sayHello = function() {
  console.log('Hello, World!')
}

sayHello();
