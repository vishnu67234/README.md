// Author: Sahil Nagpal
// GitHub: https://github.com/sahil2598
// Language: Java

class Hello_World_sahil2598
{
  	public static void main()
  	{
		System.out.println("Hello, World!");
  	}
}
