-- LANGUAGE: Haskell
-- AUTHOR: Brent Scheppmann
-- GITHUB: https://github.com/bareon
-- COMPILE: ghc --make hello_world_bareon.hs -o hello
module Main where

main :: IO ()
main = putStrLn "Hello World!!"

