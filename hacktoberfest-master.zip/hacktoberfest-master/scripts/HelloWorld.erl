#!/usr/bin/env escript
%% -*- erlang -*-

main(_)->
  io:format("Hello World").
