// LANGUAGE: Scala
// ENV: JVM
// AUTHOR: Grégoire Guémas
// GITHUB: https://github.com/navispeed

object HelloWorld {
  def main(args: Array[String]) = {
    println("Hello World")
  }
}
