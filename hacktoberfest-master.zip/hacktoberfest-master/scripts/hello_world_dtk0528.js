// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Kuan Tung
// GITHUB: https://github.com/dtk0528

console.log('Hello, World!');
