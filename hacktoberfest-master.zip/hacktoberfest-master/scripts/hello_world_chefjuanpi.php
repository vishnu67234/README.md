<?hh
  // LANGUAGE: Hack
  // ENV: HHMV
  // AUTHOR: Juan Pablo Aguilar-Lliguin
  // GITHUB: https://github.com/chefjuanpi

  echo 'Hello, World!';

?>
