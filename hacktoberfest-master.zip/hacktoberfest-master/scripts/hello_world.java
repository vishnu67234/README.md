/*
  LANGUAGE: JAVA
  AUTHOR: Savitoj Singh
  GITHUB: https://github.com/phoenix157
*/

public class hello_world {

    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }

}
