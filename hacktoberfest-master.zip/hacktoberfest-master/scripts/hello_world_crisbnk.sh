// LANGUAGE: bash
// AUTHOR: Cristiano Bianchi
// GITHUB: https://github.com/crisbnk

#!/bin/bash
echo "Hello, World!"
