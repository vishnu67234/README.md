//Language: lua
// ENV: Github :)
// Author: LegacyGDev
// Github: https://github.com//LegacyGDev

print("Hello World")
