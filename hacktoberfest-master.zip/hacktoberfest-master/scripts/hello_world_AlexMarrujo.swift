// LANGUAGE: Swift
// ENV: Console
// AUTHOR: Alex Marrujo
// GITHUB: https://github.com/marrujoalex

let helloWorld: String = "Hello, World!"
print(\(helloWorld))
