/*
  LANGUAGE: JAVA
  AUTHOR: Nethmi WIjesinghe
  GITHUB: https://github.com/Nethmi96
*/

public class HelloJavaN {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}
