# Language: Python
# Github: http://github.com/jatin0312/

print("Hello World")
