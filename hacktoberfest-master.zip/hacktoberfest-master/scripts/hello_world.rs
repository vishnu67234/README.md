// LANGUAGE: Rust
// AUTHOR: Ishan Jain
// GITHUB: https://github.com/ishanjain28/
fn main() {
    println!("Hello, World!");
}
