// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Laks

console.log('Hello, World!');
