-- LANGUAGE: Haskell
-- ENV: GHCi
-- AUTHOR: Leonardo Santos Monteiro
-- GITHUB: https://github.com/quatroka

main = putStrLn "Hello, World!"
