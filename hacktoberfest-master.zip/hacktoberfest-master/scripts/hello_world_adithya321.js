// LANGUAGE: Javascript
// // ENV: Node.js
// // AUTHOR: Adithya J
// // GITHUB: https://github.com/adithya321
//
console.log('Hello, World!');
