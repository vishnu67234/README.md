// LANGUAGE: JavaScript
// ENV: Node.js
// AUTHOR: Unal Muslu
// GITHUB: https://github.com/sasalx

'use strict'

const hello = "Hello World"

console.log(hello);
alert(hello);