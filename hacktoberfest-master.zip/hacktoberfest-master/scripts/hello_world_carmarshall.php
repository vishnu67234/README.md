<?php
// LANGUAGE: PHP
// ENV: PHP
// AUTHOR: Carlyn Marshall

echo "Hey there!";
echo "Hi there!";
echo "Hoe there!";

?>
