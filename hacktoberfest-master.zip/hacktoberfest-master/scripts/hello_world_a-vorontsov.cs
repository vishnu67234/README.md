
//* LANGUAGE: C#
//* AUTHOR: Aleksandr Vorontsov
//* GITHUB: https://github.com/a-vorontsov/

using System;
using System.Collections.Generic;
using System.Text;

namespace HelloWorld
{
    class HelloWorld
    {
        static void Main()
        {
            Console.WriteLine("Hello, world!");
        }
    }
}