# LANGUAGE: Ruby
# AUTHOR: Ahmad Thames
# GITHUB: https://github.com/ahmadthames

puts "Hello World!"