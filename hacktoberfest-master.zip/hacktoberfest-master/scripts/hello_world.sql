-- LANGUAGE: SQL
-- ENV: MySQL
-- AUTHOR: Eugene Dzhumak
-- GITHUB: https://github.com/elforastero

SELECT 'Hello, World!';
