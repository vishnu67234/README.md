// LANGUAGE: C
// ENV: C.c
// AUTHOR: Mario Hirotoshi
// GITHUB: https://github.com/riverm4n

#include<stdio.h>

int main(){
  print("Hello World!")
  return 0;
}
