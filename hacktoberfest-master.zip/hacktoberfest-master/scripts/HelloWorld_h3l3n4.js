// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Helena Tepe
// GITHUB: https://github.com/h3l3n4

console.log('Hello, World!');
