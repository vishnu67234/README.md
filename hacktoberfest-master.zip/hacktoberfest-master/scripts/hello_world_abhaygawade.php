<?php

// LANGUAGE: PHP
// ENV: Core PHP
// AUTHOR: Abhay Gawade
// GITHUB: https://github.com/abhaygawade

echo 'Hello, World!';