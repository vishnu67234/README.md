# LANGUAGE: Bash
# AUTHOR: Teja D
# GITHUB: https://www.github.com/TD87

echo "Hello World"
