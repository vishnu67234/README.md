![IgluLabs Softwares](http://dzw7f3rrk6q3f.cloudfront.net/wp-content/uploads/2017/07/logo-WitsxsTagLine_150x150.png?x37601)

### About

- [Main Website](https://www.iglulabs.com)

### Location

Pune, Maharashtra, India

### Work

Cloud Lead at IgluLabs Softwares Pvt. Ltd.

### Interests

- Web development
- Cloud Architecture
- Software Architecture
- Chess

### Github Profile

- [Shehzad Shaikh](https://github.com/cyberrspiritt)
