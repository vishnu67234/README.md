# Yusuf Eren Utku

### Location

Istanbul/Turkey

### Academics

Selcuk University

### Interests

- Android

### Development

- Inventor of the [OneMeme](https://play.google.com/store/apps/details?id=com.mememaker.android)
- Inventor of the [Drinking Games](https://play.google.com/store/apps/details?id=com.drinkinggames.android)
- Developer of the [ING Mobile](https://play.google.com/store/apps/details?id=com.ingbanktr.ingmobil)

### Projects

- [Widget Tutorial for Android](https://github.com/yerenutku/WidgetExamples) There are 4 example of Android Widgets based on [this](https://medium.com/android-bits/android-widgets-ad3d166458d3) article. 

### Profile Link

[yerenutku](https://github.com/yerenutku)