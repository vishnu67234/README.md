# Sanjeev Kumar

### Location

Kolkata, India

### Academics

Jadavpur University, Kolkata

### Interests

- Machine Learning
- Artificial Intelligence
- Open Source
- Movies
- Travelling

### Development

- Open Source developer
- Data Science

### Profile Link

[Sanjeev](https://github.com/sanjeevbitx)
