# Niket Mishra

### Academics

- KIIT University (B.Tech)
- Tecnológico de Monterrey campus Querétaro

### Interests

- Competitive Coding
- Web Development 
- Android Development
- Game Development using Unity

### Projects

- [Bingo Crunch](https://github.com/niketmishra/Bingo-Crunch-) Android game on classical bingo.
- [Run2Play](https://github.com/niketmishra/Run2play) PC game.
- Cross platform application


### Profile Link

[Niket Mishra](https://github.com/niketmishra)