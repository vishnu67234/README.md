# Ivo Ketelaar

### Location

The Netherlands

### Academics

Hanze University of Applied Sciences

### Interests

- Gaming
- Programming
- Game Design and Development
- Modding

### Development

- A Hexagonal World

### Projects

- [Koxel](http://github.com/koxel/koxel) Koxel is an open-world, survial, exploration RPG, played in an 'infinite' hexagonal world.
- [BattleHex](http://github.com/ikstreamivo/battlehex) BattleHex is a small game for Ludum Dare 38.
- [HexaTracks](http://github.com/ikstreamivo/hexatracks) HexaTracks is a small game with procedural board generation for Ludum Dare 39.

### Profile Link

[IKStreamIvo](http://github.com/ikstreamivo)