# Patrick Hübl-Neschkudla

### Location

Vienna, Austria

### Job

Senior Developer @ ovos media gmbh

### Interests

- Web-Development
- Deep Learning and Neural Networks
- Video- & Board-Games
- Music

### Projects

- [rocklegend.org](https://rocklegend.org/) 
- [ovos play game designer](http://www.ovosplay.com/gd_en.html)
- Tons of websites and apps.

### Profile Link

[flipace](https://github.com/flipace)
