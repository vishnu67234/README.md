# Søren Eriksen

### Academics

- Studying Computer Science at Aarhus University

### Interests

- Application Development
- Business Development
- Machine Learning

### Projects

- None yet :/

### Profile Link

[Søren Eriksen](https://github.com/soer7022)