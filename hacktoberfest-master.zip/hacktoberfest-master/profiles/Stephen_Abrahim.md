# Stephen Abrahim

### Location

Huntington Beach, CA, USA

### Academics

Current Comp Sci Student at UCI

### Interests

-Games!!!

### Development

- Gameplay software engineer

### Projects

-Battle Birds

### Profile Link

[Stephen Abrahim](https://github.com/Lepah)
