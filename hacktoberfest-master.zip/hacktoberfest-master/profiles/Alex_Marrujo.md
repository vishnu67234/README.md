# Alex Marrujo

### Location

Orange, CA

### Academics

B.S. Mathematics with Computer Science, California State University, San Bernardino

### Interests

- Swift in general (backend and iOS)
- Muay Thai
- Gym
- Video games
- Music (mostly electronic)
- Messing around with different tech

### Development

- Android app for company I work for, along with iOS and Windows projects

### Projects

- Private Repo for iOS stuff ;)

### Profile Link

[Alex Marrujo](https://github.com/marrujoalex)
