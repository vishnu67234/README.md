# Justin de Leon

### Location

Quezon City, Philippines

### Academics

Centro Escolar University, Manila

### Interests

- Web Development

### Development

- Web Apps using Laravel

### Projects

- See my github profile for open-source contributions

### Profile Link

[Justin de Leon](https://github.com/jusdeleon)
