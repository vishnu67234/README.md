# Rubens Pinheiro

### Location

Berlin, Germany

### Academics

Ceará's State University (UECE) - Brazil

### Interests

- Surfing
- Playing Basketball
- Cooking new recipes
- Video Games

### Development

Working since 2007 with JavaScript, but also have extensive
knwoledge in Python, and worked with other languages as PHP and C/C++

### Profile Link

[Rubens Pinheiro](https://github.com/rubenspgcavalcante)
