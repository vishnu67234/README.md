# Ataeraxia

### Languages

* Javascript
* Java / Android
* ~~HTML and CSS~~ just kidding of course

### Projects

Just one worth metioning: [Material Counter]("https://play.google.com/store/apps/details?id=com.madscarf.materialcounter&hl=en"), an app on the Google Play Store.

### Interests

* Games
* Jokes
* Stories

### Profile Link

[Ataeraxia]("https://github.com/Ataeraxia")