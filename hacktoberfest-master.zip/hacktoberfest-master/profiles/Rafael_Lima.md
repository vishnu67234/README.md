# Rafael O. M. Lima

### Location

Belo Horizonte, Brazil

### Academics

8th sem IT undergrad. Expected grad: December'18

### Interests

- Data Structure
- Algorithm Designing
- Machine Learning
- Computer Games
- Microservices Engineer
- Memes

### Projects

### Profile Link

[Rafael Lima](https://github.com/rafaelkalan)