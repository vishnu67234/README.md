# Tristan Caulfield

### Location

- Memphis, TN

### Academics

- University of Memphis

### Interests

- Home Automation, Automotive Mechanics, Fishing, Camping

### Development

- Annoyer of Wife

### Projects

- [Home Assistant Config](https://github.com/Bahnburner/Home-Assistant-Config) A repo containing the configuration and automations for my smart home. 

### Profile Link

[Bahnburner](https://github.com/Bahnburne)
