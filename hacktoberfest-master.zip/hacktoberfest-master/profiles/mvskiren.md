# Mvs kiran

### Location

Kakinada,Andhrapradesh, India

### Academics

Pragati coellge, kakinada

### Interests

- Machine learning.

### Development

- Websites.
- Home AUTOMATION.

### Projects

- web devlopment sites.

### Profile Link

[Mvs kiran](https://github.com/mvskiren)
