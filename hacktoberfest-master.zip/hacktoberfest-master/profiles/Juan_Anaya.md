# Juan Anaya Ortiz

### Location

Granada, Spain

### Academics

University of Granada, IT Engineer.

### Interests

- Cloud Computing
- Android development.
- Security and those things.
- I like all geek-style things.

### Development

- Android, Kotlin indeed.
- JavaScript.
- TDD.
- Java and C++.

### Projects

- I have a few in hands, but almost all are for the university.

### Profile Link

[Juan Anaya Ortiz](https://github.com/JaoChaos)

### Social links to contact:

Twitter: Xx_JaoChaos_xX
Telegram: @JaoChaos

