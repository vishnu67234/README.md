# Githae Kevin

### Location

Turin/Italy

### Academics

Computer Engineering ,Turin University

### Interests

- Data Structure
- Algorithm Designing
- Machine Learning

### Development

- Dev at Kaggle

### Projects

- [Cluster Analysis](https://github.com/Kevogich/Cluster-Analysis) Plotting from an analysis with R

### Profile Link

[GITHAE KEVIN](https://github.com/Kevogich)
