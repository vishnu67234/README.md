# Rohit Mathew

### Location

Bangalore, Karnataka, India

### Academics

SRM University, Chennai

### Interests

- Coding and Development
- Music (I am a beatboxer and an avid musician)
- Football (Big Manchester United fan #GGMU)

### Development

- Built multiple android applications for companies.
- Former Software Intern/Hacker at [HackerRank](https://github.com/interviewstreet/)
- Freelance Android Developer.

### Projects

- Most of them are either Hackathon ideas which I want to develop into products later or applications developed for companies.

### Profile Link

[Rohit Mathew](https://github.com/rohitjmathew/)
