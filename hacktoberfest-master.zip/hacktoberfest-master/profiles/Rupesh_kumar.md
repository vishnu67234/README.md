# Rupesh Kumar

### Academics

Undergraduate in B.Tech (Information Technology) from KIIT University

### Interests

- User Interface and User Experience
- Javascript-Based Technologies
- Node, Express, React/Redux, Sequelize, Postgres
- Sockets
- Memes

### Development

- Frontend UI Engineer, Fullstack Software Engineer



### Projects


### Profile Link

[Rupesh kumar](https://github.com/vmcniket)