# Jason Lin

### Location

New York City / USA

### Academics

Stuyvesant High School

### Interests

- Web Development
- Learning different coding languages
- Spinning Poi

### Projects

- [Client Facing App for Spectator Newspaper Website](https://github.com/stuyspec/client-app) Newspaper website for my school

### Profile Link

[Jason Lin](https://github.com/JasonLin43212)
