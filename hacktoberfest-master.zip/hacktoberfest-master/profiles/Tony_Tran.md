# Tony Tran

### Location

Springfield , MA , USA
## About me:

21 year old student finishing up his senior year of undergrad as a Computer Science major. 


## Languages, frameworks and technologies I know and use:

- Python
- Java
- HTML, CSS, JS
- MySQL
- C#
- Flask
- and more...
## Projects:

- [Coconut Karaoke](https://github.com/tonytran/CoconutKaraoke)
[Check out my portfolio](https://github.com/tonytran)

Email me: tonytran@therealtonytran.com
