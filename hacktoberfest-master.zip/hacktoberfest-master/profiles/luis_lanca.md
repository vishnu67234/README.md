# Luís Antonio Prado Lança

### Location

Jundiaí, São Paulo, Brazil

### Academics

Graduating in Analysis and Development of Systems at Fatec Jundiai

### Interests

- Web Development
- Linux
- Sports
- Nature
- Pizza

### Development

- Front-end Developer
- Designer Graphic

### Projects

- [Responsive Toolbar](https://github.com/luisslanca/menu-responsivo) A simple responsive toolbar for websites and blogs.

### Profile Link

[Luís Antonio Prado Lança](https://github.com/luisslanca)
