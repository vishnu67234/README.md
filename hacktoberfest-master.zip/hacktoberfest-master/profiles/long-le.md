# Long Le

### Location

Compiegne/France

### Academics

University of Technology of Compiegne

### Interests

- Listen to music
- Read new things

### Development

- Student 

### Projects

- [Plurinotes](https://github.com/lthlong/PluriNotes) An application for editing memos

### Profile Link

[Long](https://github.com/lthlong)
