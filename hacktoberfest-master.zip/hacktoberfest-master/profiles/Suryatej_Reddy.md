# Suryatej Reddy

### Location

New Delhi, India

### Academics

Batchelor's in Computer Science, IIITD

### Interests

- Backend Development
- Open Source
- CTF's

### Profile Link

[Suryatej Reddy](https://github.com/suryatejreddy)