# Isaac Abrahamson

### Location

Iowa City, Iowa Area, United States of America

### Academics

Homeschool

### Interests

- Video Games
- Programming
- Entrepreneurship

### Development

- freeCodeCamp staff member and forum moderator

### Projects

- [Simon Game](https://github.com/IsaacAbrahamson/Simon) A fun little remake of the classic simon game.

### Profile Link

[IsaacAbrahamson](https://github.com/IsaacAbrahamson)