# Marieluise Merz

### Location

Munich, Germany

### Academics

Universtität Augsburg, Master in Finance and Information Management, focus on Business & Information System Engineering

### Interests

- Research about Knowledge Management
- Reading Sci-Fi
- Music

### Development

- So far only school projects
- Getting started

### Projects

- Newby

### Profile Link

  [marieluisemerz](https://github.com/marieluisemerz)
