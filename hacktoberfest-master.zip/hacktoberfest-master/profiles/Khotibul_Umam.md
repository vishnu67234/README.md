# Khotibul Umam

### Location

Mojokerto, Indonesia

### Academics

Bachelor Degree with Informatic Engineering, State University Maulana Malik Ibrahim, Malang

### Interests

- Football Anything
- Video games
- Music
- Blogging

### Development

- Android app for about my private project
- Laravel app with Vue for my company project

### Projects

- Private Repo only ;)

### Profile Link

[Khotibul Umam](https://github.com/umaams)
