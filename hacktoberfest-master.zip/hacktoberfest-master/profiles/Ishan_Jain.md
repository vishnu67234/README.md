# Ishan Jain

### Location

Roorkee, Uttarakhand, India

### Academics

Undergraduating in Computer Science from College of Engineering, Roorkee.

### Interests

- Crypto
- Image Processing
- Networking
- Bicycling
- Travelling(Not that much)

### Development

- I've worked as a Part time Backend Engineer and in Devops role at clonefolio.com, jinswara.com and few more websites. 
- Love Creating APIs and Bots

### Projects

- [Pluto](https://github.com/ishanjain28/pluto) A fast Multipart File Downloader
- [imgur-bot](https://github.com/ishanjain28/imgur-bot) A imgur bot, that lets you sign in and upload images to imgur.com from Telegram.

A partially complete list can be found [here](https://ishanjain.me/projects/projects/).

### Profile Link

[Ishan Jain](https://github.com/ishanjain28/)
