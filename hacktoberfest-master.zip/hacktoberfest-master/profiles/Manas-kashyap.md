# Manas kashyap

### Academics

Undergraduate in B.Tech (Computer Science and Technology) from Amity 
university Noida 

### Interests

- User Interface and User Experience
- Javascript-Based Technologies
- Android , DBMS (Sql)
- Debian Packaging
- Penetration Testing
- Linux 
- Memes


### Profile Link

[Manas kashyap](https://github.com/Manas-kashyap)
