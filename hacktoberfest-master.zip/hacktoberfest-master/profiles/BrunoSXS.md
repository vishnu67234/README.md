# BrunoSXS

### Location

Brazil

### Academics

Marketing graduate and doing a second graduation in Analysis and systems development

### Interests

- Technology
- Game Development
- Game Design
- Javascript, Python and Java
- Progressive Rock
- I like turtles
- I LOVE DOGS

### Development

- Frontend UI Engineer, Fullstack Software Engineer

### Projects

- [SMRT-Godot](https://github.com/brunosxs/SMRT-Godot) SMRT-Godot - System for Multi Rethorical Texts for Godot is a dialog system with a fancy name

### Profile Link

[BrunoSXS](https://github.com/brunosxs)
