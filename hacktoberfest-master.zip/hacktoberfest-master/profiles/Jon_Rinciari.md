# Jon Rinciari

### Location
*New Haven, CT, USA*

### Academics
*BA, Computer Science*

### Interests
*Javascript, HTML, CSS*

### Development
*My own fancy fidget spinner*

### Projects
[Jon Rinciari Portfolio](www.jrincedevelopment.com)