# Rafael Barbosa

### Location

Sao Bernardo do Campo, Sao Paulo, Brazil

### Academics

Mackenzie Universidade Presbiteriana

### Interests

- Open Source, Networking

### Development

- Website

### Profile Link

[Rafael Barbosa](https://github.com/rafaelmilanibarbosa)