# Panagiotis Vlachos

### Location

Athens, Greece

### Academics

University of Piraeus, Digital Systems Department (Piraeus, Greece)

### Interests

- Playing/Listening music
- Bicycling
- Gaming
- Meeting friends
- Traveling

### Development

- C, C#, Java
- Python, Django, Ruby on Rails
- Android JDK, Java for native Android apps
- ReactJS
- LUCENE

### Projects

- See my GitHub profile :)
- Currently working on an admin-panel with ReactJS

### Profile Link

[PanosVl](https://github.com/PanosVl)
