# Zakaria Soufiani

### Location

Brisbane, Australia

### Academics

University of Queensland

### Interests

- Merge conflicts 

### Development

- Personal

### Projects

- [AWS lambda Angular Tutorial](https://github.com/zakaria-soufiani/medium-testmedium-test) Simple app with Angular and AWS lambdas

### Profile Link

[Zakaria Soufiani](https://github.com/zakaria-soufiani/medium-test)
