# Rafael Bezerra

### Location

Fortaleza - CE/Brazil

### Academics

Estacio FIC, Analysis and systems development

### Interests

- Software Development
- Books
- Games

### Profile Link

[rafaelbezerra195](https://github.com/rafaelbezerra195)