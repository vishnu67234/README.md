# Juan Milano

### Location

Venezuela

### Academics

System Engineer

### Interests

- Gamining and programming

### Development

- Html, CSS, PHP, python, flash

### Projects

- Custom UI for conky https://github.com/milanojs/Config
- Custom keyboard shortcuts to tmux https://github.com/milanojs/Config
- Digital Signing Alfresco plugin spanish Translate https://github.com/milanojs/DigitalSigning 

### Profile Link

[Juan Milano](https://github.com/milanojs)
