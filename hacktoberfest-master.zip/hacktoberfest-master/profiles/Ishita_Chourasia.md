Ishita Chourasia

### Location

Bangalore, India

### Academics

DAIICT, Gandhinagar

### Interests

Programming
Painting
Volleyball

### Projects

Grocery-store-management
https://github.com/ishitach/Grocery-store-management
This application is for managing and maintaining records of the items in the grocery store. Items can be added, deleted or modified. Also, details of each item can be added.

### Profile Link

ishitach
https://github.com/ishitach

