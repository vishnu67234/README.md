# Joel Guerra

### Location

Seattle

### Academics

Dev Bootcamp

### Interests

Building cars
Racing cars
Collecting guns
Competetive shooting

### Development

Free lance projects.

### Projects

- [Whiteboardr](http://whiteboardr.herokuapp.com) a web app for developers to practice their technical interview skills.
- [Police Watch](http://policewatch.herokuapp.com) Visualization of all police officer involved homocides in the US from 2015-2016.

### Profile Link

[Joel Guerra](http://joelguerra.ninja)