# Clark Weckmann

### Location

USA

### Academics

College - SWIC

### Interests

- Web Development
- NodeJs
- Tea

### Development

- ClarkHacks.com
- Gmail Send API

### Projects

- [Node Gmail API](https://github.com/clarkhacks/Gmail-API) Make a Quick N' Dirty Gmail API!

### Profile Link

[ClarkHacks](https://github.com/clarkhacks)
