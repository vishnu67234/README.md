# Indra Kusuma

### Location

Semarang, Indonesia

### Academics

Dian Nuswantoro University

### Interests

- Full Stack Developer

### Development

- Codeigniter
- Laravel
- Java

### Projects

- [FLS Guide](https://github.com/creativefls/voteApp) Vote Apps Future Leader Summit 2017

### Profile Link

[Indra Kusuma](https://github.com/idindrakusuma)
