# Daniel Hernández

### Location

Caracas, Venezuela

### Academics

IB Diploma student at The British School Caracas

### Interests

- Programming
- Reading
- Tennis
- Web development
- Algorithmic trading and finance
- MATHEMATICS
- Machine learning and artificial intelligence

### Development

- Node.js
- JavaScript
- Python
- Octave
- Tensorflow

### Projects

- [Sunnyside Software Web Development](http://www.sunnysidecode.com/) - helping new businesses navigate the waters of the web!
- [PyAlgosim](http://dhdaniel.github.io/PyAlgosim/) - a stock trading simulator and backtester using algorithmic techniques.

### Profile Link

[Daniel Hernández (DHDaniel)](https://github.com/DHDaniel/)
