# Kevin Castillo

### Location

Los Angeles, California

### Academics

California State University-Los Angeles

### Interests

- Fantasy Football
- AI
- MEAN Stack

### Development

- NovaJoy Developer

### Projects

- TechIt a work order system

### Profile Link

[Kevin Castillo](https://github.com/kcastil7)
