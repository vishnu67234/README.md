# techtide

- student developer who makes things that are of interest

- GITHUB: [techtide](https://github.com/techtide/) 
