# Irfan

### Location

Bandung, Indonesia

### Academics

Padjadjaran University

### Interests

- Mathematics
- CS

### Development

- Android
- OCR Development

### Projects

- OCR - A matlab program to recognize font from webcam
- Mustika Store - A website that sell music equipment

### Profile Link

[irfannafri](https://github.com/irfannafri)
