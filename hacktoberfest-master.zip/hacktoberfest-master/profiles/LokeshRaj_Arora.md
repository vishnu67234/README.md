# Lokesh Raj Arora
### Location

Darjeeling , India

### Academics

Currently studying undergrad CS in Chennai, India

### Interests

- I love food and love going out, probably one of those outgoing yet nerdy devs, I love open source.

### Development

- I work primarily in Node, React, React-Native, Electron. Have a love feeling towards Python lately <3 ! I do a little bit of shell-scripting too !

### Profile Link

[Lokesh Raj Arora](https://github.com/lokiiarora/)
