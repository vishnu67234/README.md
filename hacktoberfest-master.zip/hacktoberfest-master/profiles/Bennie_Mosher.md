# Bennie Mosher

### Location

Windsor, Colorado, United States of America

### Interests

- Fly Tying
- Fly Fishing
- Smart Homes
- Microservices

### Bio

- Worked at over 10 different startups
- A Polyglot Software Engineer Imposter
- I have 3 daughters
- I love coding in Ruby and JavaScript

### Projects

- [NOMO FOMO - Your Ultimate Social Travel Platform](https://nomo-fomo.com)

### Profile Link

[Bennie Mosher](https://github.com/benniemosher)
