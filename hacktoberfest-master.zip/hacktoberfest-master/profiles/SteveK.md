Academics

West Chester Uni

Interests

Software development
Video games
Computer assembly
Security
Forensics

C++
Java
PowerShell
Python


