# Douglas Feuser

### Location

Santa Catarina, Brazil

### Academics

UFSC

### Development

- Personal

### Interests

- Cyber Security, ethical hacking, JS,

### Profile Link

[DouglasFeuser](https://github.com/DouglasFeuser)
