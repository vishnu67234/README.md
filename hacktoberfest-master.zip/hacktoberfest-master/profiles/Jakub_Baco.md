# Jakub Bačo

### Location

Slovakia / Czech Republic

### Academics

Currently studying software engineering in Prague

### Interests

- Design on point
- Artificial Intelligence
- Skateboarding
- Cardistry
- really dark jokes

### Projects

- Browser based text editor (ms word like)
- Catastrophy.js which basically destroy your page :D (not done yet)
- Working on some AIs

### Profile Link

[Jakub Bačo](https://github.com/vysocina)
