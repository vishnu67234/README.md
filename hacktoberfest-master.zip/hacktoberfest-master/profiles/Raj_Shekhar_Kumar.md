# Raj Shekhar Kumar

### Location

Delhi, India

### Academics

NIT Delhi

### Interests

I like to take part in Competitive Programming Challenges and learn new technologies.

### Certificates

Database for Developers (Oracle) - Learned about Database usage for Web Developers using Structured Query Language.
JavaScript (Udacity) - Learned JavaScript syntax and coding conventions that web developers use to create interactive and dynamic websites.
Offline Web Applications (Udacity) - Learned how to develop offline-first web application using Service Workers and IndexedDB.

### Profile Link

[Raj Shekhar Kumar](https://github.com/rja907)
