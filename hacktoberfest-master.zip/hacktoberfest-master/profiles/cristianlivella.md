# Cristian Livella

### Location

Bergamo, Lombardia, Italia

### Academics

ITIS Pietro Paleocapa - Bergamo

### Interests
- PHP
- MySQL
- JavaScript

### Development

- [BgSchool](https://bgschool.cristianlivella.com/)

### Projects

- [ArgoAPI](https://github.com/cristianlivella/ArgoAPI)

### Profile Link

[Cristian Livella](https://github.com/cristianlivella)