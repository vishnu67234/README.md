# Federico Sebastián Sassone

### Location

Rafael Calzada, Buenos Aires, Argentina

### Academics

Universidad de Buenos Aires

### Interests

- Music
- Videogames
- Solving Problems
- Playing Sports

### Development

- Working at Appdirect

### Profile Link

[fedeSassone](https://github.com/fedesassone/hacktoberfest)
