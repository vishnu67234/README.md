# Carlyn Marshall

### Location

Lancaster, PA, USA

### Academics

BS Degree in Computer Science, Millersville University in Pennsylvania

### Interests

- Pina Coladas
- Getting caught in the rain
- Solving puzzles

### Development

- Currently employed as a Back-end Web Developer

### Projects

- nothing overwhelmingly exciting ...yet!

### Profile Link

[Carlyn Marshall](https://github.com/carmarshall)
