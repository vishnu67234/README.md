# Leonardo Wajnsztok

### Location

Leonardo Wajnsztok

### Academics

Undergraduate in Computer Engineering at PUC-Rio

### Interests

- Machine learning
- Big data
- Natural language processing
- Python
- STAR WARS

### Development

- Big Data intern

### Projects

- [iOS SpriteKit Level Generator with Moore Neighborhood Algorithm](https://github.com/leotok/spritekit-level-generator-moore-neighborhood) 

### Profile Link

[Leonardo Wajnsztok](https://github.com/leotok)
