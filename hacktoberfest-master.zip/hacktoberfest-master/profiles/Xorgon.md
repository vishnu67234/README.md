# Elijah 'Xorgon' Andrews

### Location

Southampton, United Kingdom

### Academics

University of Southampton

### Interests

- Programming, gaming, aerospace engineering.

### Development

- Worked on a variety of Minecraft plugins, university work, and miscellaneous projects.

### Projects

- [XFilter](https://github.com/Xorgon/XFilter) XFilter is a very simple, easy-to-use chat filter plugin for Bukkit/Spigot.
- [Quadcopter-Project](https://github.com/Xorgon/Quadcopter-Project) Quadcopter Group Design Project repository.
- [Map-Generator](https://github.com/Xorgon/Map-Generator) A procedural generator of Tolkien-style maps.

### Profile Link

[Xorgon](https://github.com/xorgon)
