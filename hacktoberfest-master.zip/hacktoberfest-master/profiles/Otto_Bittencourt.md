# Otto Bittencourt

### Location

Belo Horizonte, Minas Gerais , Brazil

### Academics

Pontificia Universidade Catolica de Minas Gerais - Puc-Mg

### Interests

- Old games
- TV Series
- Music

### Development

- Nothing Important. Yet.

### Projects

- 

### Profile Link

[Otto Bittencourt](https://github.com/OttoWBitt)
