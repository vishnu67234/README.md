# Hi, I'm S.
Nice to see you looking at this.

# Some things you may wanna know about me:
I love [The Register](https://www.theregister.co.uk)

I mostly program in [Python](https://python.org)

I love making things with [Discord](https://discordapp.com)

You can find some more things about me at [my website](https://www.banne.club).

Cya!

**-S**
