# Shelby Stanton

### Location

Leeds, England

### Academics

Information Technology BSc from University of Leeds

### Interests

- UI design
- Sass, Coffeescript, Laravel, Vue, ES6
- Imgur, Reddit, Gifs in general.
- Foundation, Bootstrap 4, October CMS
- Gaming (I LOVE Final Fantasy and The Witcher!)
- My cats, Oscar and Charlie!

### Development

- Front End Developer hoping to become an expert in PHP!

### Projects

- [Personal site](https://github.com/Minimilk93/minimilk93.github.io) My personal site
- [October CMS Foundation](https://github.com/Minimilk93/october-foundation) Recently been playing around with October CMS and decided to make a Foundation theme for it.

### Profile Link

[Shelby Stanton](https://github.com/Minimilk93)