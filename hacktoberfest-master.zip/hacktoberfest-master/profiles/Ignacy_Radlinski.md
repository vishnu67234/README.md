Ignacy
Radliński

### Location

Poland, Cracow

### Academics

AGH UST Cracow

### Interests

Star Wars
birds
horror movies

### Projects

SimonGame
https://github.com/radlinskii/web-repo/tree/master/simonGame
Cool old game made by myself as a project for free code camp certificate 

### Profile Link

radlinskii
https://github.com/radlinskii
