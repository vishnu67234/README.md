# Debashish Nayak

### Location
Roorkee, Uttarakhand, India

### Academics
Undergrad at Indian Institute of Technology Roorkee

### Interests
- anime, manga, pokemon, photography

### Projects
- [Personal Website](https://github.com/theindianotaku/theindianotaku.github.io) My personal website

### Profile Link
[Debashish Nayak](https://github.com/theindianotaku)
