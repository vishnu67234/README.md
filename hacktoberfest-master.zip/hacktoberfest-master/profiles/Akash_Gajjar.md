# Akash Gajjat

### Location

Ahmedabad/India

### Academics

J M Chaudhary Sarvajanik Vidhyalaya, Mehsana

### Interests

- Movies
- Binge Watching TV Shows
- Web Development
- Graphic Designing
- Travelling
- Reading articles on Medium
- Photography

### Development

- Developed my brain to watch good movies and recommend it to others.

### Projects

- [Cyber Chat](https://github.com/skywalker212/cyber-chat) a web chat application,with basic chat functionality.
- [Onine Personal Dictionary](https://github.com/skywalker212/my-dictionary) A simple dictionary app with add and remove terms functionality
- [Countdown Page](https://github.com/skywalker212/portfolio-countdown) A Countdown timer page for My Portfolio Site
- [FindWiki](https://github.com/skywalker212/FindWiki) This a web page that searches for wikipidia articles for a given query.
- [TwitchCheck](https://github.com/skywalker212/TwitchCheck) This is a webpage that checks whether the given list of channels are streaming currently.
- [Random Quote Generator] (https://github.com/skywalker212/Random-Quote-Generator) A web page that generates quote for your inspiration when you press the button.
- [Tiny Shell] (https://github.com/skywalker212/tinyShell) An Assignment for my course of System Software

### Profile Link

[Akash Gajjar](https://github.com/skywalker212)