# gipsi

### Location

Your South-East, UK

### Academics

FreeCodeCamp, Coursera, EdX, FutureLearn

### Interests

- I'm passionate about horses

### Development

- Learning Full Stack Web Development

### Projects

- [Bemused Unicorn](https://gipsi.github.io) This is a PWA project
  I'm currently working on so I'm focusing on service-workers
  and responsive design as I learn JavaScript and improve html
  and css skills.

### Profile Link

[gipsi](https://github.com/gipsi)
