# Jeevan Chapagain

### Location

Balaju, Kathmandu, Nepal

### Academics

Asian School of Management and Technology

### Interests

- Algorithm.
- Technology.
- Sports.

### Development

- Web Application.


### Projects

- Job Aggregator - A web app to provide the job listing from all the jobs site in one place using information retrieval.

### Profile Link

[Jeevan Chapagain](https://github.com/jeevanc)
