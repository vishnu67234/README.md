# Matthias Kraus

### Location

Munich, BY, Germany

### Academics

Undergraduate in B.A. (Automotive Computer Science) from THI

### Interests

- A lot of stuff
- Reading
- Mountaineering
- ...

### Development

- Mountainrescue Map

### Projects

- Mountainrescue Map

### Profile Link

[brotkiste](https://github.com/brotkiste)
