# Pongsakorn Ajchariyasakchai

### Location

Bangkok/Thailand

### Academics

Kasetsart University

### Interests

Data Mining

### Development

Python

