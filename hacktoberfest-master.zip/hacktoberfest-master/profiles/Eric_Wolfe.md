# Eric Wolfe

### Location

Edwardsville USA

### Academics

Southern Illinois University Edwardsville

### Interests

- Programming
- Music
- Gaming

### Development

- Currently working on a image uploader for imgur.

### Projects

- [Brew Ops](https://github.com/brew-ops) Organization that I started to make applications and test ideas that are not covered in school.

### Profile Link

[Eric Wolfe](https://github.com/erwolfe)
