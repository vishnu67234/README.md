# Ethan L

### Location

Canada

### Academics

University of Waterloo

### Interests

- Movies, Programming, Drawing

### Development

- Inventor of the Arm Braces for Baseball Players

### Projects

- [Dank tanks](https://github.com/athenafromage/Dank-Tanks) Game about tanks in Python

### Profile Link

[athenafroamge](https://github.com/athenafromage)
