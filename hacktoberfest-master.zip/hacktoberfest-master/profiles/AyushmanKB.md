# Ayushman KB

### Location

Calcutta, WB, India

### Interests
* bio-informatics
* android (UI|DEV)
* digital art (inkscape)

### Development
* Starting to engage the Open Source community
* Programming in Python, Java(Android|Scala|Kotlin), and some other (obscure) languages ~ 

### Projects
* Improve programming skills (specially in Java|Perl)
* Engage in Open Source projects and contribute to the community

### Profile Link

[namhsuya](https://github.com/namhsuya/)
