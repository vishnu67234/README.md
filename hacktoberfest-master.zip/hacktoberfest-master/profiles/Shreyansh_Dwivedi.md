# Shreyansh Dwivedi

### Location

Varanasi, India

### Academics

Indian Institute Of Information Technology, Allahabad

### Interests

- Web Dev
- Action Movies

### Development

- Full Stack Developer (backend in django)

### Projects

- [QA Forum](https://github.com/shreyanshdwivedi/QAforum) Django Project similar to StackOverflow

### Profile Link

[Shreyansh Dwivedi](https://github.com/shreyanshdwivedi)
