# Aleksandr Vorontsov

### Location

London, England

### Academics

MSci Computer Science, King's College London (starting 2018)

### Interests

- Playing the piano
- Nice UI
- Music

### Development

- Front-end Web Developer

### Projects

- [GoLink](https://github.com/a-vorontsov/golink) Proximity-based instant messaging app developed during the PokemonGo craze.

### Profile Link

[Aleksandr Vorontsov](https://github.com/a-vorontsov)
