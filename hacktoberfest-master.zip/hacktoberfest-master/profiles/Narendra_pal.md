# Narendra Pal	
### Academics
- Currently Pursuing B.Tech. from MNNIT Allahabad.
- MNNIT ALLAHABAD

### Interests

- Competetive Coding. Python Scripting. Data mining. 


### Projects

- [Sports-Naarad](https://github.com/npcoder2k14/HackInTheNorth-PYRAG) 

### Profile Link

[npcoder2k14](https://github.com/npcoder2k14)
