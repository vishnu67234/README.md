# Alice Chuang

### Location

New York City, NY, USA

### Academics

Undergraduate in B.A. (Management Information Systems) from Babson College

### Interests

- User Interface and User Experience
- Javascript-Based Technologies
- Node, Express, React/Redux, Sequelize, Postgres
- Sockets
- Memes
- I LOVE DOGS

### Development

- Frontend UI Engineer, Fullstack Software Engineer

### Projects

- [SLYDV](https://github.com/EvilDeds/slydv) A presentation slide-creation tool for Developers
- [GIPHY Meme Generator](https://github.com/AliceWonderland/giphy-meme) A desktop app lets you create your own custom memes. Built using Electron and GIPHY API

### Profile Link

[Alice Chuang](https://github.com/AliceWonderland)