# Cameron Smith

### Academics

DeVry University (2010-2011)
Butler Community College (2016-2017)

### Interests

- Software development
- Video games
- Computer assembly
- Traveling

### Development

- C++
- Python
- Java
- HTML
- CSS
- JavaScript
- VB.NET

### Projects

- [TextRPG](https://github.com/cameronzsmith/TextRPG/tree/master/TextRPG) - My text RPG made for my C# class final.
- [Pong](https://github.com/cameronzsmith/UnityTutorials/tree/master/Pong) - My pong clone made in Unity.
- [Space Invaders](https://github.com/cameronzsmith/UnityTutorials/tree/master/Space%20Invaders) - My space invader clone made in Unity.
- [Web Hosting Website Template](https://github.com/cameronzsmith/web-final) - My HTML/CSS class final, a mock website hosting company website.
- [Mock WoW Guild Website Template](https://github.com/cameronzsmith/codenamecurse) - Unfinished project, but the starting mockup for a WoW guild website.

### Profile Link

[GitHub](https://github.com/cameronzsmith)
[Artstation](https://www.artstation.com/czsmith7)