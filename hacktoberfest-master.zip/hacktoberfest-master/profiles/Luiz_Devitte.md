# Luiz Devitte

### Location

Ribeirão Preto, SP, Brazil

### Interests
* Artificial Intelligence
* Theoretical and Applied Physics
* Programming and Modelling

### Development
* Starting to engage the Open Source community
* Programming in Python, C#, MATLAB and some other (obscure) languages

### Projects
* Improve programming skills (specially in Python and C#)
* Engage in Open Source projects and contribute to the community

### Profile Link

[LuizDevitte](https://github.com/LuizDevitte)
