# Hassan Sani

### Location

Abuja/Nigeria

### Academics

University of Maiduguri

### Interests

- Traveling, Sharing my knowledge, Interacting, Movies

### Development

- Building an Open Source Political Platform

### Projects

- [ADP Nigeria](https://github.com/ADPNigeria/adpnewdesign) The Web page of a political party in Nigeria

### Profile Link

[Hassan Sani](https://github.com/iNidAName)
