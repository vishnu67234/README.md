# Trevor Meadows

### Location

Charlotte, NC, USA

### Academics

UNC Charlotte coding bootcamp student,

Certified mechanical draftsman


### Interests

- Architecture 
- Javascript-Based Technologies
- Raspberry Pi
- UI/UX

### Development

- Fullstack student

### Projects

- Soon to be completed.

### Profile Link

[Trevor Meadows](https://github.com/tlm04070)